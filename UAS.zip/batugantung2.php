<?php include "header.php"; ?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <title>Pesan Paket Wisata</title>
</head>

<body>
  <div class="container">
    <h1>Pesan Paket Wisata</h1>
    <form>
      <div class="form-group">
        <label for="nama">Nama</label>
        <input type="text" class="form-control" id="nama" placeholder="Masukkan nama Anda">
      </div>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" placeholder="Masukkan alamat email Anda">
      </div>
      <div class="form-group">
        <label for="telepon">Nomor Telepon</label>
        <input type="tel" class="form-control" id="telepon" placeholder="Masukkan nomor telepon Anda">
      </div>
      <div class="form-group">
        <label for="destinasi">Destinasi</label>
        <select class="form-control" id="destinasi">
          <option>Pilih destinasi</option>
          <option>Destinasi 1</option>
          <option>Destinasi 2</option>
          <option>Destinasi 3</option>
        </select>
      </div>
      <div class="form-group">
        <label for="tanggal">Tanggal</label>
        <input type="date" class="form-control" id="tanggal">
      </div>
      <button type="submit" class="btn btn-primary">Pesan</button>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>

</html>