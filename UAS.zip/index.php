<?php include "header.php"; ?>

  <div class="jumbotron">
    <h1 class="display-5">SELAMAT DATANG DI WEBSITE PARIWISATA DANAU TOBA PARAPAT</h1>
    <p class="lead">Nikmati keindahan alam dan budaya di danau toba.</p>
  </div>

    <!-- Awal script Slider/ Carousel -->
    <div id="contoh-carousel" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#contoh-carousel" data-slide-to="0" class="active"></li>
        <li data-target="#contoh-carousel" data-slide-to="1"></li>
        <li data-target="#contoh-carousel" data-slide-to="2"></li>
      </ol>

      <div class="carousel-inner" role="listbox">
      <!-- Awal script Slider pertama -->
        <div class="item active">
          <div class="col-md-10">
                <h4> </h4>
          <img src="foto/pb.jpeg" alt="Berisi keterangan gambar" width="60%">
        </div><!-- Akhir script Slider pertama -->


        <!-- Awal script Slider kedua -->
        <div class="item">
          <div class="col-md-10">
                <h4> </h4>
          <img src="foto/parapatpb.jpg" alt="Berisi keterangan gambar" width="60%">
        </div><!-- Akhir script Slider kedua -->

    </div>
    <!-- Awal script Button Geser Kiri dan Kanan -->
    <a class="left carousel-control" href="#contoh-carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
    </a>
    
    <a class="right carousel-control" href="#contoh-carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
    </a><!-- Akhir script Button Geser Kiri dan Kanan -->
    
    </div><!-- Akhir script Slider/Carousel --><br><br><br>
<?php include "footer.php"; ?>