<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$nama=$_POST['nama'];
$email=$_POST['email'];
$pesan=$_POST['pesan'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into destinasi(nama_destinasi,lokasi,deskripsi,tanggal_dibuka,telepon,email) 
                        values ('$nama', '$email', '$pesan')");

if($simpan==true){

    header("location:kritik-dan-saran.php?pesan=inputBerhasil");
} else{
    echo "Error";
}
