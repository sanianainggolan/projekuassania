<?php include "header.php"; ?>




</header>
  <main role="main">
    <section class="jumbotron text-center">
      <div class="container">
        <h1 class="jumbotron-heading">DANAU TOBA</h1>
        <p class="lead text-muted"> Danau Toba adalah sebuah keajaiban alam yang sangat menakjubkan. Danau ini diperkirakan terbentuk dari letusan dahsyat sebuah gunung api, Gunung Toba, yang terjadi sekitar 74.000 tahun yang lalu. Dengan luas lebih dari 1.145 kilometer persegi dan kedalaman 450 meter, Danau Toba sebenarnya lebih mirip lautan daripada danau. </p>
        <p>
          <a href="#" class="btn btn-primary">Jelajahi Lebih Lanjut</a>
        </p>
      </div>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
      <div class="container">
    <div class="row">
          <div class="col-md-3">
                <h4> </h4>
               <img src="foto/pantaibebas.jpg" width="200" class="img-round" alt="selamat datang">
        </div>
        <div class="col-md-3">
               <h4> </h4>
               <img src="foto/kapal.jpg" width="200"  class="img-circle" alt="ihan batak">
        </div>
        <div class="col-md-3">
                 <h4> </h4>
                 <img src="foto/san.jpg" width="600" class="img-thumbnail" alt="pantai">
        </div>
        <div class="col-md-3">
               <h4> </h4>
               <img src="foto/parapat.jpg" width="200" class="img-responsive" alt="danau">    
        </div>
        
    </section>

  <div class="container">
    <div class="row">
      
      </div>
    </div>
  </div>

  

  <!-- Menghubungkan script JavaScript Bootstrap -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>