<?php include "header.php"; ?>


</header>
    <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="card mb-4">
          <img class="card-img-top" src="foto/batugantung.jpg" alt="Destinasi 1">
          <div class="card-body">
            <h5 class="card-title">Batu Gantung</h5>
            <p class="card-text">Batu Gantung ini terletak di Parapat, tepatnya pada tepi Danau Toba sehingga tidak jauh dari Pulau Samosir. Untuk mencapainya, biasanya para wisatawan harus menaiki kapal atau speedboat sekitar 10-15 menit dari Hotel pinggiran Danau Toba. Ketika sampai, detikers akan melihat pahatan bebatuan yang unik.di balik keindahannya, Batu Gantung ternyata memiliki cerita yang diyakini masyarakat sekitar sebagai sebuah legenda.</p>
  
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card mb-4">
          <img class="card-img-top" src="foto/situmurun.jpg" alt="Destinasi 2">
          <div class="card-body">
            <h5 class="card-title">Air Terjun Situmurun</h5>
            <p class="card-text">Tempat wisata ini berlokasi di Desa Situmurun, Kecamatan Lumban Jalu, airnya mengalir langsung menuju Danau Toba Pesonanya dapat dinikmati dari atas kapal maupun berenang langsung di sekitar aliran.tingginya saja mencapai 70 meter dengan 7 tingkatan. Tak heran bila pesonanya membuat pelancong rela menempuh perjalanan jauh. Air terjun yang oleh warga setempat disebut juga Binangalom ini berjarak kurang lebih 70 kilometer dari Kota Balige.</p>
 
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card mb-4">
          <img class="card-img-top" src="foto/kaldera.jpg" alt="Destinasi 3">
          <div class="card-body">
            <h5 class="card-title">The Kaldera Toba Nomadic Escape</h5>
            <p class="card-text">Objek wisata The Kaldera Toba Nomadic Escape di kawasan Danau Toba, Kecamatan Ajibata, Kabupaten Toba, adalah salah satu tujuan wisata masyarakat Sumatera Utara. mengenai pemandangan, dari The Kaldera Toba Nomadic Escape dapat melihat Desa Sigapiton, yaitu desa yang diapit oleh dua bukit tinggi di kanan kirinya. Sigapiton merupakan desa wisata yang digagas oleh Kementerian Pariwisata. Destinasi ini berdiri di atas lahan Zona Otorita Pariwisata Danau Toba seluas lebih dari dua hektare.</p>
            
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>