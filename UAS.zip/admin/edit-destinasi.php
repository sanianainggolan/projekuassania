<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-edit-destinasi.php" method="POST">
                <?php
                $id=$_GET['id'];
                include "../koneksi.php";
                $tampil=$koneksi->query("select * from destinasi where destinasi_id='$id'");
                $row=$tampil->fetch_assoc();
                ?>
                    <div class="form-group">
                        <label for="nama_destinasi">Nama Destinasi</label>
                        <input type="hidden" name="destinasi_id" value="<?php echo $row['destinasi_id']?>" class="form-control">
                        <input type="number" name="nama_destinasi" value="<?php echo $row['nama_destinasi']?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="lokasi">Lokasi</label>
                        <input type="text" name="lokasi" value="<?php echo $row['lokasi']?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control"><?php echo $row['deskripsi']?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="tanggal_dibuka">Tanggal Dibuka</label>
                        <input type="date" name="tanggal_dibuka" value="<?php echo $row['tanggal_dibuka']?>" class="form-control">
                    </div>

                        <div class="form-group">
                        <label for="telepon">Telepon</label>
                        <input type="text" name="telepon" value="<?php echo $row['telepon']?>" class="form-control">
                    </div>

                        <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" name="email" value="<?php echo $row['email']?>" class="form-control">
                    </div>      

                    <input type="submit" name="kirim" value="UBAH" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

<?php include "footer.php";?>