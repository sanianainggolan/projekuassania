 <?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$nama_destinasi=$_POST['nama_destinasi'];
$lokasi=$_POST['lokasi'];
$deskripsi=$_POST['deskripsi'];
$tanggal_dibuka=$_POST['tanggal_dibuka'];
$telepon=$_POST['telepon'];
$email=$_POST['email'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into destinasi(nama_destinasi,lokasi,deskripsi,tanggal_dibuka,telepon,email) 
                        values ('$nama_destinasi', '$lokasi', '$deskripsi', '$tanggal_dibuka', '$telepon','$email')");

if($simpan==true){

    header("location:tampil-destinasi.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>