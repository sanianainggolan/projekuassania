<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$nama=$_POST['nama'];
$email=$_POST['email'];
$pesan=md5($_POST['pesan']);


include "../koneksi.php";

$simpan=$koneksi->query("insert into user(nama,email,pesan) 
                        values ('$nama', '$email', '$pesan',now())");

if($simpan==true){

    header("location:tampil-komentar.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>