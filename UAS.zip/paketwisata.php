<?php include "header.php"; ?>



</header>
<div class="album py-5 bg-light">
      <div class="container">
      </div>
        <div class="row">
          <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
              <img src="foto/batugantung1.jpg" class="card-img-top" alt="Room 1">
              <div class="card-body">
                <h5 class="card-title">Batu Gantung</h5>
                <p class="card-text">Objek wisata ini tak lepas dari keindahan bentang alam danau Toba. Deretan tebing-tebing hijau yang mengelilingi danau seakan ikut membalut keunikan fenomena alam ini. Belum lagi cerita legenda di balik keberadaan fenomena batu yang menjulang dari tebing ini. Tetu menjadi daya tarik tersendiri.</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="card-text"></p>
                </div>   
                   <p class="card-text"></p>
                   <small class="text-muted">Harga tiket masuk batu gantung gratis. Sewa kapal menuju batu gantung perorangan Rp15.000, Per kapal(tergantung jenis kapal)RP300.000-Rp.500.000</small>
                </div>
              </div>
            </div>
            </div>
          <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
              <img src="foto/sania1.jpeg" class="card-img-top" alt="Room 2">
              <div class="card-body">
                <h5 class="card -title">Air Terjun Situmurun</h5>
                <p class="card-text">Menikmati keindahan dan segarnya air terjun dengan berenang.</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="card-text-">
                  </div>   
                     <p class="card-text"></p>
                     <small class="text-muted">Harga tiket masuk Air Terjun Situmurun gratis. Sewa kapal menuju Air Terjun Rp650.000,00-4.500.000,00 Bagi yang ingin pergi dengan Speadboat Parapat-Air Terjun Situmurun Rp1.900.000</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
              <img src="foto/kalderatoba1.jpeg" class="card-img-top" alt="Room 3">
              <div class="card-body">
                <h5 class="card-title">The Kaldera Toba Nomadic Escape</h5>
                <p class="card-text">Menikmati helitour keliling Geopark Toba dan destinasi lainnya.</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="card-text"></p>
                  </div>   
                     <p class="card-text"></p>
                     <small class="text-muted">Tiket masuk ke dalam area The Kaldera Resort mulai dari umum Senin-Jumat Rp15.000
                     Sabtu,Minggu,Hari libur Umum Weekend Rp.20.000
                     Warga negara asing weekend Rp40.000
                     Homepod per malam maksimun 4 orang Rp1.200.000
                     Rental venue plaza, Kaldera stage, Meeting room Rp2.250.000 
                     Glamping Belltent per malam maksimum 3 orang Rp800.000</small>
                </div>
              </div>
            </div>
          </div>